from flask import Flask,render_template,request
import pickle
import numpy as np
app=Flask(__name__)
model = pickle.load(open('model.pkl','rb'))

@app.route('/')
def home():
    return render_template('Home.html')

@app.route('/predict',methods=['POST'])
def predict():
    sl=float(request.values['Sepal_Length'])
    sw=float(request.values['Sepal_Width'])
    pl=float(request.values['Petal_Length'])
    pw=float(request.values['Petal_Width'])

    values=np.array([[sl,sw,pl,pw]])
    output=model.predict(values)
    output=output.item()
    return render_template('Result.html',prediction_text="The Predicted Iris Species is {}".format(output))
    
if __name__== '__main__':
    app.run(debug=True)