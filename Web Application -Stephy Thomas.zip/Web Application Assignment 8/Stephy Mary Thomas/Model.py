import pandas as pd 
import pickle
from sklearn.model_selection import train_test_split 
from sklearn.linear_model import LogisticRegression

iris = pd.read_excel("C:/Users/ASUS/Desktop/DATA SCIENCE/Assignments/Web Application Assignment 8/iris.xls")
x=iris.drop("Classification",axis=1)
y=iris["Classification"]

x_train,x_test,y_train,y_test=train_test_split(x,y,random_state=42,test_size=0.2)
log_model=LogisticRegression()
log_model=log_model.fit(x_train,y_train)
y_pred=log_model.predict(x_test)
pickle.dump(log_model,open('model.pkl','wb'))